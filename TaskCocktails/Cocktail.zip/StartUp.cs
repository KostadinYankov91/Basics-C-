﻿namespace CocktailParty
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Ingredient vodka = new Ingredient("Vodka", 2, 5);
            Ingredient milk = new Ingredient("Milk", 0, 5);

            Cocktail cocktail = new Cocktail("Pina Colada", 5, 5);

            cocktail.Add(vodka);
            cocktail.Add(milk);

            cocktail.Remove("Vodka");

            cocktail.FindIngredient("Milk");

        }
    }
}
